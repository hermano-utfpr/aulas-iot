#include "contiki.h"
#include "net/ip/uip.h"
#include "net/ipv6/uip-ds6.h"
#include "net/ip/uip-udp-packet.h" 
#include "net/rpl/rpl.h"
#include "dev/leds.h"
#include <stdio.h>

#include "sys/node-id.h"

#define UDP_HDR ((struct uip_udpip_hdr *)&uip_buf[UIP_LLH_LEN])

PROCESS(node_process,"node");
AUTOSTART_PROCESSES(&node_process);

void
set_prefix_64(uip_ipaddr_t *prefix_64) {
}

PROCESS_THREAD(node_process, ev, data) {

  PROCESS_BEGIN();

     NETSTACK_RDC.off(1); 

     printf ("Node OK\n");

     static struct uip_udp_conn *udp_server;
     udp_server = udp_new(NULL,0,NULL);
     udp_bind(udp_server, UIP_HTONS(5000));

     static uip_ipaddr_t remote_ipaddr;
     uip_ip6addr(&remote_ipaddr, 0, 0, 0, 0, 0, 0, 0, 0); 

     while (1) {

        PROCESS_YIELD();

        if (ev == tcpip_event) {

           static char *appdata;
           appdata = (char *)uip_appdata;
           appdata[uip_datalen()] = 0;
           printf("%s received\n",appdata);

        }

     }

  PROCESS_END();

}

