#include "contiki.h"
#include "net/ip/uip.h"
#include "net/ipv6/uip-ds6.h"
#include "net/rpl/rpl.h"
#include "dev/leds.h"
#include <stdio.h>

#include <stdlib.h>
#include <string.h>
#include "contiki-net.h"
#include "rest-engine.h"

// Recursos REST
extern resource_t
  res_hello;


PROCESS(webserver_process,"Web Server CoAP");
AUTOSTART_PROCESSES(&webserver_process);

void
set_prefix_64(uip_ipaddr_t *prefix_64) {
}

PROCESS_THREAD(webserver_process, ev, data) {

  PROCESS_BEGIN();

     NETSTACK_RDC.off(1); 

     printf ("Web Server ok\n");

     rest_init_engine();
     rest_activate_resource(&res_hello, "hello");

     while (1) {

        PROCESS_YIELD();

     }

  PROCESS_END();

}

